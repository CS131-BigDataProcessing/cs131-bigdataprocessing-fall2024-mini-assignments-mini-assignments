#!/bin/bash

# Step 1: Remove trailing spaces
sed -i '' 's/[[:space:]]*$//' AB_NYC_2019.csv

# Step 2: Handle missing values (choose one)
# Option A: Remove rows with missing values
awk -F, 'NF==NF {print $0}' AB_NYC_2019.csv > temp.csv

# Option B: Replace missing values with 'NA'
sed -i '' 's/,,/,NA,/g' temp.csv
sed -i '' 's/,$/,NA/' temp.csv

# Step 3: Remove duplicate entries
sort temp.csv | uniq > deduped.csv

# Step 4: Identify and remove outliers (e.g., column 3 threshold)
awk -F, '$3 <= 1000 {print $0}' deduped.csv > final_cleaned.csv

# Cleanup temp files
rm temp.csv
echo "Preprocessing completed. Cleaned file: final_cleaned.csv"


