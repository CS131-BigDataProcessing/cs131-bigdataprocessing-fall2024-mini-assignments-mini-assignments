- 'preprocessing.sh': Automatically takes care of the data cleaning tasks.
- 'about_script.txt': Explains reasoning for cleaning tasks.
- Final_cleaned' is the cleaned code output.

Instructions to run the file:

-> Place the CSV file in the same directory. 
-> Run the ./preprocessing.sh

